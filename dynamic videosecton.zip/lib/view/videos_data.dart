import 'dart:convert';
import 'package:dynamicvideosection/model/videocategory_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../ui_helper/custom_colors.dart';
import '../utils/api_service.dart';

class YoutubeScreen extends StatefulWidget {
  const YoutubeScreen({super.key,required this.subcategoryId,required this.categoryName});


  final String categoryName;
  final int subcategoryId;

  @override
  State<YoutubeScreen> createState() => _YoutubeScreenState();
}

class _YoutubeScreenState extends State<YoutubeScreen> {
  late YoutubePlayerController youtubePlayerController;
  late YoutubeMetaData videoMetaData;
  var isPlayerReady = false;
  var isLoading = false;

 // List videCategory = <VideoModel>[];

  List<VideoModel> videCategory = [];
  //
  // Future<void> getVideoData(int subcategoryId) async {
  //   isLoading = true;
  //   final url = 'https://dev-mahakal.rizrv.in/api/v1/astro/getVideosBySubcategory/$subcategoryId';
  //   final response = await ApiService().getVideo(url);
  //   final jsonData = jsonDecode(response);
  //   final videoModels = (jsonData as List).map((jsonObject) => VideoModel.fromJson(jsonObject)).toList();
  //   List<VideoModel> videCategory= videoModels;
  //   print(videCategory);
  // }

  // Future<void> getVideoData(int subcategoryId) async {
  //   isLoading = true;
  //   final url = 'https://dev-mahakal.rizrv.in/api/v1/astro/getVideosBySubcategory/$subcategoryId';
  //   final response = await ApiService().getVideo(url);
  //   // Assuming response is already a decoded JSON object (Map/List)
  //   if (response != null) {
  //     videCategory = List<VideoModel>.from(response.map((model) => VideoModel.fromJson(model)));
  //     isLoading = false;
  //     print(videCategory);
  //     setState(() {});
  //   } else {
  //     // Handle error or empty response
  //     isLoading = false;
  //     // setState(() {}); // Only call setState if you need to update UI
  //   }
  // }


  Future<void> getVideoData(int subcategoryId) async {
    isLoading = true;
    final url = 'https://dev-mahakal.rizrv.in/api/v1/astro/getVideosBySubcategory/$subcategoryId';
    final response = await ApiService().getVideo(url);
    final videoModel = VideoModel.fromJson(response);
    setState(() {
      videCategory = [videoModel];
      print('Video Category List: ${videCategory.length}'); // Add this line
      isLoading = false;
    });
  }

  //
  // Future<void> getVideoData(int subcategoryId) async {
  //   isLoading = true;
  //   final url = 'https://dev-mahakal.rizrv.in/api/v1/astro/getVideosBySubcategory/$subcategoryId';
  //   final response = await ApiService().getVideo(url);
  //   final jsonData = jsonDecode(response);
  //   final videoModels = (jsonData as List).map((jsonObject) => VideoModel.fromJson(jsonObject)).toList();
  //   setState(() {
  //     videCategory = videoModels;
  //     print(videCategory);
  //     isLoading = false;
  //   });
  // }


  // Future<void> getVideoData(int subcategoryId) async {
  //   isLoading = true;
  //   final url = 'https://dev-mahakal.rizrv.in/api/v1/astro/getVideosBySubcategory/$subcategoryId';
  //   final response = await ApiService().getVideo(url);
  //   print(response);
  //   videCategory = videoModelFromJson(jsonEncode(response));
  //   isLoading = false;
  //   print(videCategory);
  //   setState(() {});
  // }

  @override
  void initState() {
    getVideoData(widget.subcategoryId);
    print("my id is ${widget.subcategoryId}");
    final videoID = YoutubePlayer.convertUrlToId("");
    videoMetaData = const YoutubeMetaData();
    youtubePlayerController = YoutubePlayerController(
      initialVideoId: videoID!,
      flags: const YoutubePlayerFlags(
        useHybridComposition: true,
        mute: false,
        autoPlay: true,
      ),
    )..addListener(listener);
    super.initState();
  }

  void listener() {
    if (isPlayerReady && mounted && !youtubePlayerController.value.isFullScreen) {
      setState(() {
        videoMetaData = youtubePlayerController.metadata;
      });
    }
  }

  @override
  void deactivate() {
    // Pauses video while navigating to next page.
    youtubePlayerController.pause();
    super.deactivate();
  }

  @override
  void dispose() {
    youtubePlayerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: getVideoData(widget.subcategoryId),
      builder: (context,snapshot){
        if (snapshot.connectionState == ConnectionState.done){
          return Scaffold(
            backgroundColor: CustomColors.clrwhite,
            appBar: AppBar(
              title: Text(widget.categoryName, style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Roboto',
                  color: CustomColors.clrorange),),
              centerTitle: true,
              leading: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: const Icon(
                    Icons.arrow_back, color: CustomColors.clrblack,)),
            ),
            body: SafeArea(
              child: YoutubePlayerBuilder(
                onExitFullScreen: () {
                  // The player forces portraitUp after exiting fullscreen. This overrides the behaviour.
                  SystemChrome.setPreferredOrientations(
                      DeviceOrientation.values);
                },
                player: YoutubePlayer(controller: youtubePlayerController),
                builder: (BuildContext context, Widget wid) {
                  return Column(
                    children: [
                      //AppBar(title: const Text('Live Darshan')),

                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: YoutubePlayer(
                            // thumbnail: Image.network('https://i.ytimg.com/vi/FAKH-_ZkTqQ/maxresdefault.jpg'),
                            controller: youtubePlayerController,
                            showVideoProgressIndicator: true,
                            onReady: () {
                              isPlayerReady = true;
                              print('Player is ready.');
                            },
                          ),
                        ),
                      ),

                      Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(7),
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                              color: Theme
                                  .of(context)
                                  .primaryColor
                                  .withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: Text(widget.categoryName, style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),)),

                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GridView.builder(
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                childAspectRatio: 3.0,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 20,
                                crossAxisCount: 1,
                              ),
                              itemCount: videCategory.length,
                              //itemCount: 5,
                              itemBuilder: (BuildContext ctx, int index) {
                                return InkWell(
                                  onTap: () {
                                    youtubePlayerController.load(
                                        YoutubePlayer.convertUrlToId("")!);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey.shade600),
                                        borderRadius: BorderRadius.circular(
                                            10)),
                                    child: Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment
                                          .start,
                                      children: [
                                        Expanded(
                                          flex: 1,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.grey),
                                              borderRadius:
                                              BorderRadius.circular(7),
                                              image: DecorationImage(
                                                  image: AssetImage(""),
                                                  fit: BoxFit.cover),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10, top: 5, bottom: 5),
                                            child: Text(videoMetaData.title,
                                              style: const TextStyle(
                                                  fontWeight: FontWeight
                                                      .w500),),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                      )
                    ],
                  );
                },
              ),
            ),
          );
        }
        else if (snapshot.connectionState == ConnectionState.waiting) {
          // Show a loading indicator while waiting for the data
          return Center(child: CircularProgressIndicator());
        }
        else {
          // Show an error message if the future has an error
          return Text('Error: ${snapshot.error}');
        }
        }
    );
  }


}

